#include <inc/lib.h>

void
umain(void)
{
	fprintf(1,"Enter your username: ");
	while(1);
}
