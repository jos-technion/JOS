#include <inc/assert.h>

#include <kern/env.h>
#include <kern/pmap.h>
#include <kern/monitor.h>
#include <kern/sched.h>

void queue_insert_end(struct Env* e) {
	struct Env* f;
	struct Env* prev;
	if(LIST_EMPTY(rq->active.queue + e->static_prio)) {
		LIST_INSERT_HEAD(rq->active.queue + e->static_prio, e, env_queue);
	} else {	
		for(f=LIST_FIRST(rq->active.queue + e->static_prio); f != 0; f = LIST_NEXT(f, env_queue)) {
			prev=f;
		}
		LIST_INSERT_AFTER(prev,e, env_queue);
	}
	rq->active.bitmap[e->static_prio/32] |= (1 <<(e->static_prio%32));

}
static __inline__ unsigned long __ffs(unsigned long word)
{
    __asm__("bsfl %1,%0"
        :"=r" (word)
        :"rm" (word));
    return word;
}

static inline int _sched_find_first_bit(unsigned long *b)
{
    if (unlikely(b[0]))
        return __ffs(b[0]);
    if (unlikely(b[1]))
        return __ffs(b[1]) + 32;
    if (unlikely(b[2]))
        return __ffs(b[2]) + 64;
    if (b[3])
        return __ffs(b[3]) + 96;
    return __ffs(b[4]) + 128;
}
void scheduler_tick() {
	if(curenv->time_slice-- < 0) {
		curenv->time_slice = 10 * HZ;
		sched_yield();
	}
}


// Choose a user environment to run and run it.
void
sched_yield(void)
{
	// Implement simple round-robin scheduling.
	// Search through 'envs' for a runnable environment,
	// in circular fashion starting after the previously running env,
	// and switch to the first such environment found.
	// It's OK to choose the previously running env if no other env
	// is runnable.
	// But never choose envs[0], the idle environment,
	// unless NOTHING else is runnable.

	// LAB 4: Your code here.

	//cprintf("First Bit: %d\n",_sched_find_first_bit(rq->active.bitmap));
	if(rq->nr_running ==0) { // no more environments, choosing idle task
		if (envs[0].env_status == ENV_RUNNABLE)
			env_run(&envs[0]);
		else {
			cprintf("Destroyed all environments - nothing more to do!\n");
			while (1)
				monitor(NULL);
		}
	}
	//if(curenv == NULL){
        //        curenv = &envs[0];
        //}
	struct Env* runIt;
	int bit = _sched_find_first_bit(rq->active.bitmap);
	runIt = LIST_FIRST(rq->active.queue + bit);
	for(runIt=LIST_FIRST(rq->active.queue + bit); runIt != 0; runIt = LIST_NEXT(runIt, env_queue)) {
			if(runIt->env_status == ENV_RUNNABLE)
				break;
	}
	if(runIt != NULL) {
		LIST_REMOVE(runIt,env_queue);
		queue_insert_end(runIt);
		env_run(runIt);
	} else {
		if (envs[0].env_status == ENV_RUNNABLE)
			env_run(&envs[0]);
		else {
			cprintf("Destroyed all environments - nothing more to do!\n");
			while (1)
				monitor(NULL);
		}
	}
	/*if(rq->nr_running ==0) { // no more environments, choosing idle task
		if (envs[0].env_status == ENV_RUNNABLE)
			env_run(&envs[0]);
		else {
			cprintf("Destroyed all environments - nothing more to do!\n");
			while (1)
				monitor(NULL);
		}
	}*/
        /*
        int i;
        for(i = 1; i < NENV; i++) {
                if((envs+1+(curenv+i-envs-1)%(NENV-1))->env_status == ENV_RUNNABLE) {
                        env_run(envs+1+(curenv+i-envs-1)%(NENV-1));
                }
        }
	// Run the special idle environment when nothing else is runnable.
	if (envs[0].env_status == ENV_RUNNABLE)
		env_run(&envs[0]);
	else {
		cprintf("Destroyed all environments - nothing more to do!\n");
		while (1)
			monitor(NULL);
	}*/
	
}

	



