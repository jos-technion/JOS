/* See COPYRIGHT for copyright information. */

#ifndef JOS_KERN_SCHED_H
#define JOS_KERN_SCHED_H
#ifndef JOS_KERNEL
# error "This is a JOS kernel header; user programs should not #include it"
#endif

#include <inc/queue.h>
#define MAX_PRIO 140
#define BITMAP_SIZE ((((MAX_PRIO+1+7)/8)+sizeof(long)-1)/sizeof(long))

#define likely(x)       __builtin_expect((x),1)
#define unlikely(x)     __builtin_expect((x),0)
#define HZ 		1

#define set_bit(n,bit) \
	*n |= 1 << bit
	
#define clear_bit(n,bit) \
	*n &= ~(1 << bit)

LIST_HEAD(Env_queue,Env);
struct rt_prio_array {
	int nr_active;
	unsigned long bitmap[BITMAP_SIZE];
	struct Env_queue queue[MAX_PRIO+1];
};

struct Runqueue {
	int nr_running;
	struct rt_prio_array active;
	struct rt_prio_array expired;
	struct Env *idle;
	int time;
};

// This function does not return.
void sched_yield(void) __attribute__((noreturn));
void scheduler_tick();
void queue_insert_end(struct Env* e);
#endif	// !JOS_KERN_SCHED_H
